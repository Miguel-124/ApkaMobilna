// app/login.tsx
import { View, Text, StyleSheet, Image, Pressable } from 'react-native';
import { useAuthStore } from '@/lib/store/authStore';
import { signInWithGoogle } from '@/lib/auth/google'; // to Twoja funkcja logowania przez Google

export default function LoginScreen() {
  const login = useAuthStore((state) => state.login);

  const handleLogin = async () => {
    try {
      const userData = await signInWithGoogle(); // autoryzacja i fetch do backendu
      login(userData); // zapisujemy do store
    } catch (e) {
      console.error('Błąd logowania', e);
    }
  };

  return (
    <View style={styles.container}>
      <Image source={require('@/assets/images/logo_SmartInwestor.jpeg')} style={styles.logo} />
      <Text style={styles.title}>SmartInwestor</Text>
      <Text style={styles.subtitle}>Zarządzaj swoim portfelem inwestycyjnym w prosty sposób</Text>
      <Pressable style={styles.loginButton} onPress={handleLogin}>
        <Text style={styles.loginText}>Zaloguj się przez Google</Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#121212', padding: 24 },
  logo: { width: 100, height: 100, marginBottom: 24, borderRadius: 16 },
  title: { fontSize: 32, fontWeight: 'bold', color: '#00FFFF', textShadowColor: '#00FFFF', textShadowRadius: 8 },
  subtitle: { fontSize: 16, color: '#ccc', textAlign: 'center', marginVertical: 20 },
  loginButton: { backgroundColor: '#00FFFF', padding: 12, paddingHorizontal: 24, borderRadius: 12 },
  loginText: { color: '#000', fontWeight: 'bold', fontSize: 16 },
});